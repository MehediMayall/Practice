namespace MovieStar.Core.Dto;
public class SessionUserDto
{
    public int Id { get; set; }
    public string Email { get; set; } = string.Empty;

}
