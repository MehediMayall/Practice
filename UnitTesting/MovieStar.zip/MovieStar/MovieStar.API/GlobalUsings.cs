global using Microsoft.AspNetCore.Mvc;

global using MovieStar.Service;
global using MovieStar.Data;
global using MovieStar.Core.Models;
global using MovieStar.Core.Dto;

