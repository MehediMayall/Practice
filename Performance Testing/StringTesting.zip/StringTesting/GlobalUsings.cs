global using BenchmarkDotNet;
global using BenchmarkDotNet.Attributes;
global using System.Text;
global using static System.Console;
global using System.Diagnostics;
